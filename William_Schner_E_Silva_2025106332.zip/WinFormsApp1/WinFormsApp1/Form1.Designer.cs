﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            botaorelatorio = new Button();
            botaonomenota = new Button();
            txtNome = new TextBox();
            txtNota = new TextBox();
            Relatorio = new TextBox();
            Lista = new ListBox();
            SuspendLayout();
            // 
            // botaorelatorio
            // 
            botaorelatorio.Location = new Point(281, 313);
            botaorelatorio.Name = "botaorelatorio";
            botaorelatorio.Size = new Size(75, 23);
            botaorelatorio.TabIndex = 0;
            botaorelatorio.Text = "relatorio";
            botaorelatorio.UseVisualStyleBackColor = true;
            botaorelatorio.Click += botaorelatorio_Click;
            // 
            // botaonomenota
            // 
            botaonomenota.Location = new Point(12, 83);
            botaonomenota.Name = "botaonomenota";
            botaonomenota.Size = new Size(75, 23);
            botaonomenota.TabIndex = 1;
            botaonomenota.Text = "Inserir";
            botaonomenota.UseVisualStyleBackColor = true;
            botaonomenota.Click += botaonomenota_Click;
            // 
            // txtNome
            // 
            txtNome.Location = new Point(12, 12);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(100, 23);
            txtNome.TabIndex = 2;
            txtNome.TextChanged += txtNome_TextChanged;
            // 
            // txtNota
            // 
            txtNota.Location = new Point(12, 43);
            txtNota.Name = "txtNota";
            txtNota.Size = new Size(100, 23);
            txtNota.TabIndex = 3;
            txtNota.TextChanged += txtNota_TextChanged;
            // 
            // Relatorio
            // 
            Relatorio.Location = new Point(458, 12);
            Relatorio.Multiline = true;
            Relatorio.Name = "Relatorio";
            Relatorio.ScrollBars = ScrollBars.Horizontal;
            Relatorio.Size = new Size(330, 324);
            Relatorio.TabIndex = 4;
            Relatorio.TextChanged += Relatorio_TextChanged;
            // 
            // Lista
            // 
            Lista.FormattingEnabled = true;
            Lista.ItemHeight = 15;
            Lista.Location = new Point(12, 152);
            Lista.Name = "Lista";
            Lista.Size = new Size(263, 184);
            Lista.TabIndex = 5;
            Lista.SelectedIndexChanged += Lista_SelectedIndexChanged;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(Lista);
            Controls.Add(Relatorio);
            Controls.Add(txtNota);
            Controls.Add(txtNome);
            Controls.Add(botaonomenota);
            Controls.Add(botaorelatorio);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button botaorelatorio;
        private Button botaonomenota;
        private TextBox txtNome;
        private TextBox txtNota;
        private TextBox Relatorio;
        private ListBox Lista;
    }
}
