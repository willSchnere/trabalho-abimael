using System;
using System.Windows.Forms;
namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        string[] nomes = new string[20];
        double[] notas = new double[20];
        int totalAlunos = 0;
        public Form1()
        {
            InitializeComponent();
        }
        private void txtNome_TextChanged(object sender, EventArgs e)
        {
        }
        private void txtNota_TextChanged(object sender, EventArgs e)
        {
        }
        private void botaonomenota_Click(object sender, EventArgs e)
        {
            string nome = txtNome.Text.Trim();
            string notaTexto = txtNota.Text.Trim();
            double nota;
            if (nome == "" || notaTexto == "")
            {
                MessageBox.Show("Preencha o nome e a nota.");
                return;
            }

            try
            {
                nota = Convert.ToDouble(notaTexto);
            }
            catch
            {
                MessageBox.Show("A nota deve ser um n�mero v�lido.");
                return;
            }
            int selecionado = Lista.SelectedIndex;
            if (selecionado >= 0)
            {
                nomes[selecionado] = nome;
                notas[selecionado] = nota;
                Lista.Items[selecionado] = $"{nome} - {nota:0.00}";
            }
            else
            {
                if (totalAlunos >= 20)
                {
                    MessageBox.Show("Limite de alunos atingido.");
                    return;
                }
                nomes[totalAlunos] = nome;
                notas[totalAlunos] = nota;
                Lista.Items.Add($"{nome} - {nota:0.00}");
                totalAlunos++;
            }
            txtNome.Text = "";
            txtNota.Text = "";
            Lista.ClearSelected();
        }
        private void Lista_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = Lista.SelectedIndex;
            if (index >= 0)
            {
                txtNome.Text = nomes[index];
                txtNota.Text = notas[index].ToString("0.00");
            }
        }
        private void botaorelatorio_Click(object sender, EventArgs e)
        {
            if (totalAlunos == 0)
            {
                MessageBox.Show("Nenhum aluno cadastrado.");
                return;
            }
            string relatorio = "Relat�rio da Turma:\r\n\r\n";
            double soma = 0;
            double maiorNota = notas[0];
            double menorNota = notas[0];
            string alunoMaior = nomes[0];
            string alunoMenor = nomes[0];
            int aprovados = 0;
            for (int i = 0; i < totalAlunos; i++)
            {
                relatorio += $"{nomes[i]} - {notas[i]:0.00}\r\n";
                soma += notas[i];

                if (notas[i] > maiorNota)
                {
                    maiorNota = notas[i];
                    alunoMaior = nomes[i];
                }

                if (notas[i] < menorNota)
                {
                    menorNota = notas[i];
                    alunoMenor = nomes[i];
                }

                if (notas[i] >= 7)
                {
                    aprovados++;
                }
            }
            double media = soma / totalAlunos;
            relatorio += $"\r\nM�dia da turma: {media:0.00}";
            relatorio += $"\r\nMaior nota: {maiorNota:0.00} ({alunoMaior})";
            relatorio += $"\r\nMenor nota: {menorNota:0.00} ({alunoMenor})";
            relatorio += $"\r\nAprovados : {aprovados}";

            Relatorio.Text = relatorio;
        }
        private void Relatorio_TextChanged(object sender, EventArgs e)
        {
        }
    }
}
